// Author: David De Costa
// AirplaneTile
// Creates the AirplaneTile sprite and assigns properties.

// Imports:

// Point for handling movement
import java.awt.Point;

// Check Tile.java
public class AirplaneTile extends Tile {

// Sprite:
   private final static String filename = "airplane.png";

// Constructor:
   public AirplaneTile() {
      this (0, 0);
   }

// Constructor 2:
   public AirplaneTile (int x, int y) {
      this(filename, x, y);
   }

// Constructor 3:
   public AirplaneTile (String filename, int x, int y) {
      super(filename, x, y);
   }

// Tile Movement
   public void move(int dx, int dy, int panelWidth, int panelHeight, int nextY) {
      Point point = super.getPoint();
      int width = super.getWidth();
      
      point.translate(dx, dy);
      
      // Wrapping:
      int x = point.x;
      int y = point.y;
      
      // X Wrapping:
      if (x > panelWidth) {
         x = 0;
      }
      
      if (x < 0) {
         x = panelWidth;
      }
      
      // Y Wrapping:
      if (y < 0) {
         y = panelHeight - (int) getHeight();
      }
      
      if (y > panelHeight) {
         y = 0;
      }
      
      // Setting Location
      point.setLocation(x, y);
   }

}