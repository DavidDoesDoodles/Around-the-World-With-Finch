

// Imports:

// Panel Properties and Decorative Properties:
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

// For Gradient Background:
import java.awt.GradientPaint;
import java.awt.RenderingHints;

// Updating Timer:
import javax.swing.Timer;

// Action Event/Listener
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// For getting screen dimensions
import java.awt.Toolkit;
import java.awt.Dimension;

import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;

// GamePanel EXTENDS JPANEL
public class GamePanel extends JPanel {

   private int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
   
   public static boolean isScrolling = true;
   
   private PlaneTile plane;
   
   // Scroll Timer (for quicker updates):
   private Timer scrollTimer;
   
   private int airplaneSpeed;
   
   // New Cat Position
   private int nextCatY;
   
   Image img;
   Image panth;
   Image coliseum;
   Image pyramid;
   Image statueOfJesus;
   Image stonehenge;
   
   // Constructor:
   public GamePanel() { 
      plane = new PlaneTile(0, 205); // Enemy location
      airplaneSpeed = 14;
      createScrollTimer();
      
      try {
        img = ImageIO.read(new File("background.png"));
      } catch (IOException e) {
         System.out.println("Image not found");
         img = null;
      }
      
      try {
        coliseum = ImageIO.read(new File("coliseum.png"));
      } catch (IOException e) {
         System.out.println("Image not found");
         coliseum = null;
      }
      
      try {
        panth = ImageIO.read(new File("greece.png"));
      } catch (IOException e) {
         System.out.println("Image not found");
         panth = null;
      }
      
      try {
        pyramid = ImageIO.read(new File("pyramid.png"));
      } catch (IOException e) {
         System.out.println("Image not found");
         pyramid = null;
      }
      
      try {
        stonehenge = ImageIO.read(new File("stonehenge.png"));
      } catch (IOException e) {
         System.out.println("Image not found");
         stonehenge = null;
      }
      
      try {
        statueOfJesus = ImageIO.read(new File("statueofjesus.png"));
      } catch (IOException e) {
         System.out.println("Image not found");
         statueOfJesus = null;
      }

   }
   
   // Scroll Timer Creation
   private void createScrollTimer() {
      scrollTimer = new Timer(10, 
         new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               scroll();
               repaint();
            }
         });
   }
   
   // Timer Start
   public void start() {
      scrollTimer.start();
   }
   
   // Timer Stop
   public void stop() {
      scrollTimer.stop();
   }

   @Override
   
   // paintComponent for drawing all components
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g.create();
      
      // Gradient Background Paint and creation:
      g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      Color upperColor = new Color(255, 255, 255);
      Color lowerColor = new Color(255, 255, 255);
      float lowerGradientAmount = 0f;
      float upperGradientAmount = 500f;
      GradientPaint gp = new GradientPaint(0, 0, upperColor, lowerGradientAmount, upperGradientAmount, lowerColor);
      g2d.setPaint(gp);
      g2d.fillRect(0, 0, getWidth(), getHeight());
      g2d.drawImage(img, 0, 0, null);
      g2d.drawImage(panth, 250, 800, null);
      g2d.drawImage(pyramid, 570, 600, null);
      g2d.drawImage(statueOfJesus, 890, 500, null);
      g2d.drawImage(stonehenge, 1230, 600, null);
      g2d.drawImage(coliseum, 1550, 800, null);
      plane.draw(g2d);
   }
   
   //  Movement:
   public void scroll() {
      nextCatY = (int)(Math.random() * (double)screenHeight);
      plane.move(airplaneSpeed, 0, getWidth(), getHeight(), nextCatY); 
}
}
