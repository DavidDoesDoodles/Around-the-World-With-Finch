

// Imports:

// Swing Graphics:
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;

// Graphics:
import java.awt.BorderLayout;

// ActionListener/Event:
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// KeyListener/Event:
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

// Fullscreen Imports
import java.awt.Toolkit;
import java.awt.Dimension;

// Class Header
public class Layouts extends JFrame {

// JFrame Settings: Width and Height
   private Dimension size = Toolkit.getDefaultToolkit().getScreenSize(); 
   
   // Frame Properties
   private final int FRAME_WIDTH = size.width, 
                     FRAME_HEIGHT = size.height;
   
   // GamePanel.java
   private GamePanel gamePanel;
   
  // Constructor (Frame Creation + Frame Properties)
   Layouts() {
      createFrame();
      add(createHeaderPanel(), BorderLayout.PAGE_START);
      add(createFooterPanel(), BorderLayout.PAGE_END);
      gamePanel = new GamePanel();
      add(gamePanel, BorderLayout.CENTER);
      setVisible(true);
      gamePanel.start();
   }
   
   // Footer Panel 
   private JPanel createFooterPanel() {
      JPanel panel = new JPanel();
      return panel;
   }
   
   // Header Panel
   private JPanel createHeaderPanel() {
      JPanel panel = new JPanel(); // flow layout
      return panel;
   }
   
   // Frame Creation / Frame Properties
   private void createFrame() {
      setTitle("Hack BI V ");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setSize(FRAME_WIDTH,FRAME_HEIGHT);
      setLocationRelativeTo(null);
      setFocusable(true);
      setFocusTraversalKeysEnabled(false);
   }
   
   // Get GamePanel
   public GamePanel getGamePanel() {
      return gamePanel;
   }

}