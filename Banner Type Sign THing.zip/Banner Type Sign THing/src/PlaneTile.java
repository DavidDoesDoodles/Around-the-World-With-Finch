

// Imports:

// Point for handling movement
import java.awt.Point;

// Check Tile.java
public class PlaneTile extends Tile {

// Sprite:
   private final static String filename = "airplane.png";

// Constructor:
   public PlaneTile() {
      this (0, 0);
   }

// Constructor 2:
   public PlaneTile (int x, int y) {
      this(filename, x, y);
   }

// Constructor 3:
   public PlaneTile (String filename, int x, int y) {
      super(filename, x, y);
   }

// Tile Movement
   public void move(int dx, int dy, int panelWidth, int panelHeight, int nextY) {
      Point point = super.getPoint();
      int width = super.getWidth();
      
      point.translate(dx, dy);
      
      // Wrapping:
      int x = point.x;
      int y = point.y;
      
      // X Wrapping:
      if (x > panelWidth + 1000) {
         x = -1000;
      }
      
      
      // Y Wrapping:
      if (y < 0) {
         y = panelHeight - (int) getHeight();
      }
      
      if (y > panelHeight) {
         y = 0;
      }
      
      // Setting Location
      point.setLocation(x, y);
   }

}