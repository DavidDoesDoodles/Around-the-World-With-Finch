
// Class Header
public class Runner {

private GamePanel gamePanel =  new GamePanel();

// Main Method:
   public static void main(String[] args) {
   
   // Check Layouts.java
      Layouts frame = new Layouts();
}
}
