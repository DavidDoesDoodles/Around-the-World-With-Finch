

// Imports:

// Image Imports:
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;

// Graphics:
import java.awt.Graphics2D;

// Point:
import java.awt.Point;

// Class Header:
abstract class Tile {

// Sprite File Path
   public static final String PATH = "resources" + File.separator;
   
   // All Sprites
   public static final String airplane = "airplane.png";
   public static final String background = "background.png";
   
   // Image and File:
   private Image tile;
   private File file;
   
   // Image and File Properties (width and height):
   private int height;
   private int width;
   
   // Tile Point:
   private Point point;
   
   // Constructor
   public Tile() {
      this (0, 0);
   }
   
   // Constructor
   public Tile (int x, int y) {
      this( airplane, x, y);
   }
   
   // Constructor
   public Tile(String airplane, int x, int y) {
      file = new File(PATH + airplane); // Loading File
      
      // Applying ImageObserver:
      try {
         tile = ImageIO.read(file);
      } catch (IOException e) {
         System.out.println("Image not found: " + PATH + airplane);
         tile = null;
      }
      point = new Point(x, y); // Creating Point
   
   }
   
   // Draw Method:
   public void draw (Graphics2D g2D) {
      g2D.drawImage(tile, (int) point.getX(), (int) point.getY(), null);
   }
   
   // Tile Move:
   abstract void move(int dx, int dy, int panelWidth, int panelHeight, int nextY);
   
   // Getters:
   
   // Get Width:
   public int getWidth() {
      return width;
   }
   
   // Get Height
   public int getHeight() {
      return height;
   }
   
   // Get Point
   public Point getPoint() {
      return point;
   }
  
   // Setters:
   
   // Set Point
   public void setPoint(Point location) {
      point = location;
   }
   
   // Set File
   public void setFile(File file) {
      this.file = file;
   }
   
   // Set Tile
   public void setTile(Image image) {
      tile = image;
   }

}